const titulo = document.querySelector('.titulo');
const container = document.querySelector('#container');
const botao = document.querySelector('.botao');

titulo.textContent = 'Sexta-feira de  Carnaval';
titulo.color = 'blue';

container.style.backgroundColor = '#78ef45'
container.style.width = '94%';
container.style.margin = '0 auto';
let subtitulo = '<h2>Programação Front-End</h2>'
container.innerHTML += subtitulo;

let mensagem = '<h1></h1>'
let imagem = '<img src="./img/Mickey_Mouse.png" alt="Imagem de rato">';
botao.style.backgroundColor = '#126df6'
botao.addEventListener('click', () =>{
    container.innerHTML += imagem;
    titulo.textContent = 'A'
});